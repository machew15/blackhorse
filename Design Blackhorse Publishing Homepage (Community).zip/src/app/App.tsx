import { useState } from 'react';
import '../i18n';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { WhoItsFor } from './components/WhoItsFor';
import { ExampleVerification } from './components/ExampleVerification';
import { HowItWorks } from './components/HowItWorks';
import { Features } from './components/Features';
import { TechnicalOverview } from './components/TechnicalOverview';
import { UseCases } from './components/UseCases';
import { Footer } from './components/Footer';
import { Spec } from './components/Spec';

export default function App() {
  const [view, setView] = useState<'home' | 'spec'>('home');

  if (view === 'spec') {
    return <Spec onBack={() => setView('home')} />;
  }

  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: 'Inter, system-ui, sans-serif' }}>
      <Header />
      <main>
        <Hero onViewSpec={() => setView('spec')} />
        <WhoItsFor />
        <ExampleVerification />
        <HowItWorks />
        <Features />
        <TechnicalOverview />
        <UseCases />
      </main>
      <Footer />
    </div>
  );
}