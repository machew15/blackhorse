import { Shield, FileText, CheckCircle2, Eye } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export function HowItWorks() {
  const { t } = useTranslation();
  
  const steps = [
    {
      icon: FileText,
      title: t('howItWorks.step1_title'),
      description: t('howItWorks.step1_desc')
    },
    {
      icon: Shield,
      title: t('howItWorks.step2_title'),
      description: t('howItWorks.step2_desc')
    },
    {
      icon: CheckCircle2,
      title: t('howItWorks.step3_title'),
      description: t('howItWorks.step3_desc')
    },
    {
      icon: Eye,
      title: t('howItWorks.step4_title'),
      description: t('howItWorks.step4_desc')
    }
  ];

  return (
    <section id="how-it-works" className="bg-gray-50 py-24 md:py-32">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-semibold text-gray-900 mb-4">
            {t('howItWorks.title')}
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            {t('howItWorks.subtitle')}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
          {steps.map((step, index) => (
            <div key={index} className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-12 h-12 rounded-lg bg-white border border-gray-200 flex items-center justify-center">
                  <step.icon className="w-5 h-5 text-blue-600" />
                </div>
              </div>
              <div className="pt-1">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {step.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}