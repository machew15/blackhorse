import { useTranslation } from 'react-i18next';

export function TechnicalOverview() {
  const { t } = useTranslation();
  
  return (
    <section className="bg-gray-50 py-24 md:py-32">
      <div className="max-w-4xl mx-auto px-6">
        <div className="bg-white border border-gray-200 rounded-lg p-8 md:p-12">
          <h2 className="text-2xl md:text-3xl font-semibold text-gray-900 mb-6">
            {t('technicalOverview.title')}
          </h2>
          <div className="space-y-6 text-gray-600 leading-relaxed">
            <p>
              {t('technicalOverview.paragraph1')}
            </p>
            <p>
              {t('technicalOverview.paragraph2')}
            </p>
            <p>
              {t('technicalOverview.paragraph3')}
            </p>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-200">
            <a 
              href="#documentation" 
              className="inline-flex items-center text-blue-600 hover:text-blue-700 font-medium"
            >
              {t('technicalOverview.link_text')}
              <svg 
                className="w-4 h-4 ml-1" 
                fill="none" 
                stroke="currentColor" 
                viewBox="0 0 24 24"
              >
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={2} 
                  d="M9 5l7 7-7 7" 
                />
              </svg>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}