import { useTranslation } from 'react-i18next';

export function Hero({ onViewSpec }: { onViewSpec: () => void }) {
  const { t } = useTranslation();
  
  return (
    <section className="bg-white py-24 md:py-32">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center space-y-6">
          <h1 
            className="text-5xl md:text-6xl font-semibold text-gray-900 tracking-tight leading-tight"
            dangerouslySetInnerHTML={{ __html: t('hero.headline') }}
          />
          <p className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
            {t('hero.description')}
          </p>
          <p className="text-base text-gray-500 max-w-2xl mx-auto leading-relaxed">
            {t('hero.details')}
          </p>
          <p className="text-sm text-gray-400 pt-2">
            {t('hero.spec_version')}
          </p>
          <div className="pt-4 flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={onViewSpec}
              className="px-6 py-3 bg-gray-900 text-white rounded-md hover:bg-gray-800 transition-colors font-medium"
            >
              {t('hero.view_spec')}
            </button>
            <a 
              href="#verify" 
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-md hover:border-gray-400 hover:bg-gray-50 transition-colors font-medium"
            >
              {t('hero.verify_content')}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}