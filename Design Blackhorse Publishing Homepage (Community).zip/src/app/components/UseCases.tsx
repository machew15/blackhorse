import { useTranslation } from 'react-i18next';

export function UseCases() {
  const { t } = useTranslation();
  
  const cases = [
    {
      title: t('useCases.case1_title'),
      description: t('useCases.case1_desc')
    },
    {
      title: t('useCases.case2_title'),
      description: t('useCases.case2_desc')
    },
    {
      title: t('useCases.case3_title'),
      description: t('useCases.case3_desc')
    },
    {
      title: t('useCases.case4_title'),
      description: t('useCases.case4_desc')
    }
  ];

  return (
    <section className="bg-white py-24 md:py-32">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-semibold text-gray-900 mb-4">
            {t('useCases.title')}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {cases.map((useCase, index) => (
            <div 
              key={index} 
              className="p-6 bg-gray-50 rounded-lg"
            >
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {useCase.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {useCase.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}