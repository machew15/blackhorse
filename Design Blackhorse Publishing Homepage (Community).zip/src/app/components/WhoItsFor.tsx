import { useTranslation } from 'react-i18next';

export function WhoItsFor() {
  const { t } = useTranslation();

  const audiences = [
    {
      title: t('whoItsFor.publishers.title'),
      items: [
        t('whoItsFor.publishers.item1'),
        t('whoItsFor.publishers.item2'),
        t('whoItsFor.publishers.item3')
      ]
    },
    {
      title: t('whoItsFor.readers.title'),
      items: [
        t('whoItsFor.readers.item1'),
        t('whoItsFor.readers.item2'),
        t('whoItsFor.readers.item3')
      ]
    },
    {
      title: t('whoItsFor.researchers.title'),
      items: [
        t('whoItsFor.researchers.item1'),
        t('whoItsFor.researchers.item2')
      ]
    }
  ];

  return (
    <section className="bg-white py-24 md:py-32 border-t border-gray-200">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-semibold text-gray-900 mb-4">
            {t('whoItsFor.title')}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          {audiences.map((audience, index) => (
            <div key={index}>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                {audience.title}
              </h3>
              <ul className="space-y-3">
                {audience.items.map((item, itemIndex) => (
                  <li key={itemIndex} className="text-gray-600">
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}