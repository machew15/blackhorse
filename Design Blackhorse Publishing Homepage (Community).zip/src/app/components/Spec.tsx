import { useTranslation } from 'react-i18next';

export function Spec({ onBack }: { onBack: () => void }) {
  const { t } = useTranslation();
  
  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: 'Inter, system-ui, sans-serif' }}>
      <div className="max-w-4xl mx-auto px-6 py-16">
        {/* Header */}
        <div className="mb-16 pb-8 border-b border-gray-200">
          <h1 className="text-4xl font-semibold text-gray-900 mb-4">
            {t('spec.title')}
          </h1>
          <p className="text-xl text-gray-600 mb-2">
            {t('spec.version')}
          </p>
          <p className="text-base text-gray-500">
            {t('spec.published')}
          </p>
          <p className="text-sm text-gray-400 mt-4 italic">
            {t('spec.canonical_note')}
          </p>
        </div>

        {/* Content */}
        <div className="space-y-12 text-gray-700 leading-relaxed">
          {/* Section 1 */}
          <section>
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">
              {t('spec.section1.title')}
            </h2>
            <p className="mb-4">
              {t('spec.section1.p1')}
            </p>
            <p className="mb-2">
              {t('spec.section1.p2')}
            </p>
            <p>
              {t('spec.section1.p3')}
            </p>
          </section>

          {/* Section 2 */}
          <section>
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">
              {t('spec.section2.title')}
            </h2>
            <p className="mb-4">
              {t('spec.section2.p1')}
            </p>
            <p className="mb-3">{t('spec.section2.p2')}</p>
            <ul className="list-none space-y-2 mb-4 pl-6">
              {(t('spec.section2.list', { returnObjects: true }) as string[]).map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
            <p>
              {t('spec.section2.p3')}
            </p>
          </section>

          {/* Section 3 */}
          <section>
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">
              {t('spec.section3.title')}
            </h2>
            <p className="mb-4">
              {t('spec.section3.p1')}
            </p>
            <div className="bg-gray-50 border border-gray-200 rounded px-4 py-3 mb-4">
              <code className="text-sm text-gray-800" style={{ fontFamily: 'monospace' }}>
                {t('spec.section3.code')}
              </code>
            </div>
            <p>
              {t('spec.section3.p2')}
            </p>
          </section>

          {/* Section 4 */}
          <section>
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">
              {t('spec.section4.title')}
            </h2>
            <p className="mb-4">
              {t('spec.section4.p1')}
            </p>
            <p className="mb-3">{t('spec.section4.p2')}</p>
            <ul className="list-none space-y-2 mb-4 pl-6">
              {(t('spec.section4.list', { returnObjects: true }) as string[]).map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
            <p>
              {t('spec.section4.p3')}
            </p>
          </section>

          {/* Section 5 */}
          <section>
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">
              {t('spec.section5.title')}
            </h2>
            <p className="mb-4">{t('spec.section5.p1')}</p>
            <ul className="list-none space-y-2 mb-4 pl-6">
              {(t('spec.section5.list', { returnObjects: true }) as string[]).map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
            <p>
              {t('spec.section5.p2')}
            </p>
          </section>

          {/* Section 6 */}
          <section>
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">
              {t('spec.section6.title')}
            </h2>
            <p className="mb-3">{t('spec.section6.p1')}</p>
            <ul className="list-none space-y-2 mb-4 pl-6">
              {(t('spec.section6.list', { returnObjects: true }) as string[]).map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
            <p>
              {t('spec.section6.p2')}
            </p>
          </section>

          {/* Section 7 */}
          <section>
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">
              {t('spec.section7.title')}
            </h2>
            <p className="mb-3">{t('spec.section7.p1')}</p>
            <ul className="list-none space-y-2 mb-4 pl-6">
              {(t('spec.section7.list1', { returnObjects: true }) as string[]).map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
            <p className="mb-3">{t('spec.section7.p2')}</p>
            <ul className="list-none space-y-2 pl-6">
              {(t('spec.section7.list2', { returnObjects: true }) as string[]).map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
          </section>
        </div>

        {/* Footer */}
        <div className="mt-16 pt-8 border-t border-gray-200">
          <button
            onClick={onBack}
            className="text-blue-600 hover:text-blue-700 transition-colors"
          >
            {t('spec.back')}
          </button>
        </div>
      </div>
    </div>
  );
}