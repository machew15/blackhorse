import { useTranslation } from 'react-i18next';

export function Footer() {
  const { t } = useTranslation();
  
  // Split the license text to extract and link the CC BY 4.0 part
  const licenseText = t('footer.license');
  const ccLinkText = 'CC BY 4.0';
  const parts = licenseText.split(ccLinkText);
  
  return (
    <footer className="bg-white border-t border-gray-200">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="mt-16 pt-8 border-t border-gray-200">
          <p className="text-sm text-gray-500 text-center">
            {t('footer.copyright')}
          </p>
          <p className="text-sm text-gray-500 text-center mt-2">
            {parts[0]}
            <a 
              href="https://creativecommons.org/licenses/by/4.0/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-gray-700 hover:text-gray-900 underline"
            >
              {ccLinkText}
            </a>
            {parts[1]}
          </p>
        </div>
      </div>
    </footer>
  );
}