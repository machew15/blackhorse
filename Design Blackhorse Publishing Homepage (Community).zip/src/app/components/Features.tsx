import { Lock, GitBranch, Clock, FileCheck } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export function Features() {
  const { t } = useTranslation();
  
  const features = [
    {
      icon: Lock,
      title: t('features.feature1_title'),
      description: t('features.feature1_desc')
    },
    {
      icon: GitBranch,
      title: t('features.feature2_title'),
      description: t('features.feature2_desc')
    },
    {
      icon: Clock,
      title: t('features.feature3_title'),
      description: t('features.feature3_desc')
    },
    {
      icon: FileCheck,
      title: t('features.feature4_title'),
      description: t('features.feature4_desc')
    }
  ];

  return (
    <section id="protocol" className="bg-white py-24 md:py-32">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-semibold text-gray-900 mb-4">
            {t('features.title')}
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            {t('features.subtitle')}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="p-8 border border-gray-200 rounded-lg hover:border-gray-300 transition-colors"
            >
              <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center mb-4">
                <feature.icon className="w-5 h-5 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}