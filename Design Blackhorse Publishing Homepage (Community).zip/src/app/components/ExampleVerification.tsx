import { useTranslation } from 'react-i18next';

export function ExampleVerification() {
  const { t } = useTranslation();
  
  return (
    <section className="bg-white py-24 md:py-32 border-t border-gray-200">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-semibold text-gray-900 mb-4">
            {t('exampleVerification.title')}
          </h2>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg p-8">
          <div className="mb-6">
            <p className="text-sm text-gray-500 mb-2">{t('exampleVerification.article_label')}</p>
            <p className="text-lg text-gray-900">
              "{t('exampleVerification.article_title')}"
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <span className="text-green-600 mt-1">✓</span>
              <div>
                <p className="text-sm text-gray-500">{t('exampleVerification.status_label')}</p>
                <p className="text-gray-900">{t('exampleVerification.status_verified')}</p>
              </div>
            </div>

            <div>
              <p className="text-sm text-gray-500 mb-1">{t('exampleVerification.signed_by')}</p>
              <p className="text-gray-900">{t('exampleVerification.publisher_name')}</p>
            </div>

            <div>
              <p className="text-sm text-gray-500 mb-1">{t('exampleVerification.canonical_hash')}</p>
              <p 
                className="text-gray-900 break-all" 
                style={{ fontFamily: 'monospace', fontSize: '14px' }}
              >
                8f3a2c91d1b4e7...
              </p>
            </div>

            <div className="flex gap-8">
              <div>
                <p className="text-sm text-gray-500 mb-1">{t('exampleVerification.version')}</p>
                <p className="text-gray-900">1.0</p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">{t('exampleVerification.timestamp')}</p>
                <p className="text-gray-900">{t('exampleVerification.timestamp_value')}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 bg-amber-50 border border-amber-200 rounded-lg p-8">
          <div className="mb-4">
            <div className="flex items-start gap-3 mb-4">
              <span className="text-amber-600 mt-1">⚠</span>
              <div>
                <p className="text-sm text-amber-700">{t('exampleVerification.status_label')}</p>
                <p className="text-gray-900">{t('exampleVerification.status_edited')}</p>
              </div>
            </div>

            <div>
              <p className="text-sm text-gray-500 mb-2">{t('exampleVerification.version_chain')}</p>
              <p className="text-gray-700">
                {t('exampleVerification.version_chain_value')}
              </p>
            </div>
          </div>
        </div>

        <div className="mt-6 text-center">
          <p className="text-sm text-gray-500">
            {t('exampleVerification.note')}
          </p>
        </div>
      </div>
    </section>
  );
}