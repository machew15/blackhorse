
  # Design Blackhorse Publishing Homepage (Community)

  This is a code bundle for Design Blackhorse Publishing Homepage (Community). The original project is available at https://www.figma.com/design/UsgGhMYQBCOFc67x3U5Qm3/Design-Blackhorse-Publishing-Homepage--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  